import { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { Link, Outlet, useLoaderData } from "@remix-run/react";
import { Button, ICartShop, Text } from "~/components";




export const loader = async ({ request }: LoaderFunctionArgs) => {
  return null;
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const form = await request.formData();
  const action = form.get("action");


};

export default function Layout() {
 

  return (
    <div className="w-full min-h-screen bg-whitecontrast">
      <div className=" max-w-[1400px] mx-auto">
        <HeaderMenu />
        <main className="px-2 md:px-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
}



const HeaderMenu = () => {
  return (
    <div className="flex p-2 py-2 px-2 md:px-4">
      <nav className="w-full py-4 grid grid-cols-8">
        <div className="col-span-3">
          <a href="/">Logo</a>
        </div>
        <div className="col-span-3"></div>
        <div className="col-span-2 flex justify-end items-center">
          <Button>
            Mi carrito
          </Button>
        </div>
      </nav>
    </div>
  );
};

