export enum IRole {
  ADMIN = "ADMIN",
  CLIENT = "CLIENT",
}
