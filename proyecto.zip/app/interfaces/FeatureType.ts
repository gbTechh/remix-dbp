export enum IFeatureType {
  SELECT = "SELECT",
  COUNTER = "COUNTER",
  CHECKBOX = "CHECKBOX",
}
