# proyectocreado con astro

Este proyecto consiste en un gestor de menus para un restaurantes o algun negocio que quiera vender sus comidas y exponer sus productos

# Integrantes
- Rodrigo Silva Murillo
- Dianiela Perales Estada
- Jose Cornejo Castro


![Link de github](https://github.com/gbTechh/remix-dbp)



## 🧞 Commands


| Command                   | Action                                           |
| :------------------------ | :----------------------------------------------- |
| `npm install`             | Installs dependencies                            |
| `npx prisma migrate`             GEenrar base de datos      |
| `npx prisma generate`           |          |

